<?php
	$dbhost="localhost";
	$dbName="cideacauca";
	$dbUser="root";
	$dbPassword="";
?>